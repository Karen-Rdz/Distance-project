import scipy.io
import matplotlib.pyplot as plt
import csv 

score = []
with open('score.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        for i in row:
            score.append(int(i))

channels=['FP2','FP1','C4','C3','P8','P7','O1','O2']

PRC = scipy.io.loadmat('PRC.mat')   #PowRatios Codes
PowRatio = 10       #See PowRatioCodes
Channel = 4         #Use codes from above
#Try different Channels or PowRatios

sreal=[1, 2, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17] #Subject number
x = []

for k in range(0, len(sreal)):
    
    if score[k]<=21:
        col='g'     # No fatigue
    if score[k]>21 and score[k]<35:
        col='y'   # Normal fatigue
    if score[k]>=35:
        col='r'     #Extreme fatigue

    file1 = 'S'+str(sreal[k])+'_powratios6.mat'
    
    Pow_ratios = scipy.io.loadmat(file1)

    x.append(Pow_ratios['Pow_ratios'][PowRatio-1, Channel-1])

    plt.plot(x[k],score[k], col+'o')
    
# y is the variable we want to predict
y = score

xlab = str(PRC['PRC'][0, PowRatio-1]) + ' (' + str(channels[Channel-1]) + ')'
plt.xlabel(xlab)
plt.ylabel('FAS Score') # Fatigue Score

plt.show()

# Fatigue classification according to FAS: 
clas = []
for i in range(len(y)):
    clas.append(2)    # Normal fatigue

for i in range(len(y)):
    if y[i] <= 21:
        clas[i] = 1     # No fatigue   
    elif y[i] >= 35:
        clas[i] = 3     # Extreme Fatigue                 
                     
# You can try some Machine Learning codes to predict and compare
# classifications (Use Data - 70% for Training, 30% for Testing)

         
