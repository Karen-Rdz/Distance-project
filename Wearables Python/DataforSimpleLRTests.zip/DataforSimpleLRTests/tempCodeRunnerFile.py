clas = ones(size(y)).*2                
# c1 = find(y<=21)        # Normal fatigue
# clas(c1) = 1            # No fatigue
# c3 = find(y>=35)
# clas (c3) = 3   